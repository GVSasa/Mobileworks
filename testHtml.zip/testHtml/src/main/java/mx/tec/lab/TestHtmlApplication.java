package mx.tec.lab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestHtmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestHtmlApplication.class, args);
	}

}
