package mx.tec.lab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestHtml2Application {

	public static void main(String[] args) {
		SpringApplication.run(TestHtml2Application.class, args);
	}

}
