package mx.tec.lab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestDatabaseApplication.class, args);
	}

}
