package mx.tec.lab;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;


class OtherClassTest {
	AnyClass ab = new AnyClass();
OtherClass ac = new OtherClass();
	int x = 1;
	int y = 2;
	void testMultiply() {
		
		 assertEquals(1*2,ac.multiply(x, y));
	}
	
	@Test
	public void testMultiply_ExceptionIsThrown() {
		try {
			ac.multiply(1000, 0);
		}
		catch(IllegalArgumentException e) {
			assertEquals("X should be less than 1000",e.getMessage());
		}
		
		}
	
	
		}

