package mx.tec.lab;

public class AnyClass {
	public void methodThatShouldThrowException() {
		throw new UnsupportedOperationException("Operation Not Supported");
		}
}
