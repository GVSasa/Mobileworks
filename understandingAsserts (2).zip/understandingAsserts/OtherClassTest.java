package mx.tec.lab;

import org.junit.jupiter.api.Test;

class OtherClassTest {
OtherClass ac = new OtherClass();
AnyClass ab = new AnyClass();	
	@Test
	void testMultiply() {
		ac.multiply(5,6);
	}

	@Test
	public void testMultiply_ExceptionIsThrown() {
		ab.methodThatShouldThrowException();
		}
}
